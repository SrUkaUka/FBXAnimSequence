bl_info = {
    "name": "Import PLY Sequence",
    "author": "sirUka",
    "version": (1, 0, 6),
    "blender": (3, 5, 0),
    "location": "File > Import/Export",
    "description": "Import PLY Sequence",
    "doc_url": "",
    "support": "COMMUNITY",
    "category": "Import-Export",
}

import bpy
from pathlib import Path
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    StringProperty,
)
from bpy_extras.io_utils import ImportHelper
from contextlib import redirect_stdout

def import_ply(filepath):
    with redirect_stdout(None):
        bpy.ops.import_mesh.ply(filepath=filepath)

class ImportPlySeq(bpy.types.Operator, ImportHelper):
    """Load a PLY Sequence as absolute shape keys"""

    bl_idname = "import_scene.plyseq"
    bl_label = "Import PLY Seq"
    bl_options = {"REGISTER", "UNDO"}

    filename_ext = ".ply"
    filter_glob: StringProperty(default="*.ply", options={"HIDDEN"})

    files: CollectionProperty(
        name="File Path",
        description="File path used for importing the PLY sequence",
        type=bpy.types.OperatorFileListElement,
    )
    directory: StringProperty()

    relative_shapekey: BoolProperty(
        name="Relative ShapeKey",
        description="Import shapes as relative shapekeys. Uncheck to import absolute shapekeys.",
        default=True,
    )

    def execute(self, context):
        filepaths = [Path(self.directory, n.name) for n in self.files]
        if not filepaths:
            filepaths.append(self.filepath)

        self.create_shapekeys(filepaths)

        return {"FINISHED"}

    def create_shapekeys(self, filepaths):
        # import first ply
        import_ply(str(filepaths[0]))
        main_obj = bpy.context.selected_objects[-1]
        main_obj.location = [0, 0, 0]
        main_obj.rotation_euler = [0, 0, 0]

        # Create basis shape key if it doesn't exist
        if not main_obj.data.shape_keys:
            main_obj.shape_key_add(name="Basis")

        seq_len = len(filepaths)

        # Import the rest and create shape keys
        for i, filepath in enumerate(filepaths[1:]):
            import_ply(str(filepath))
            current_obj = bpy.context.selected_objects[-1]
            current_obj.location = [0, 0, 0]
            current_obj.rotation_euler = [0, 0, 0]

            # Join as shapes
            bpy.context.view_layer.objects.active = main_obj
            bpy.ops.object.join_shapes()

            # Remove imported objects
            bpy.data.objects.remove(current_obj, do_unlink=True)

        # Set keyframes or drivers for shape keys
        if seq_len > 1:
            for i, key_block in enumerate(main_obj.data.shape_keys.key_blocks):
                if i > 0:
                    key_block.value = 0.0
                    key_block.keyframe_insert("value", frame=i)
                    key_block.value = 1.0
                    key_block.keyframe_insert("value", frame=i + 1)
                    key_block.value = 0.0
                    key_block.keyframe_insert("value", frame=i + 2)

        # Set start/end time
        bpy.context.scene.frame_start = 0
        bpy.context.scene.frame_end = seq_len - 1


def menu_func_import(self, context):
    self.layout.operator(ImportPlySeq.bl_idname, text="PLY Seq As Shapekey(.ply)")


def register():
    bpy.utils.register_class(ImportPlySeq)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)


def unregister():
    bpy.utils.unregister_class(ImportPlySeq)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)


if __name__ == "__main__":
    register()
