bl_info = {
    "name": "FBXAnimSequence",
    "blender": (3, 5, 0),
    "category": "Object",
    "author": "SirUka",
    "version": (4, 0, 0),
    "description": "An addon designed to quickly generate fbx animated sequences",
    "warning": "",
    "doc_url": "",
    "tracker_url": "",
    "support": "COMMUNITY",
}

import bpy
from pathlib import Path
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    StringProperty,
)
from bpy_extras.io_utils import ImportHelper

class ImportFbxSeq(bpy.types.Operator, ImportHelper):
    """Load a FBX Sequence as absolute shape keys"""

    bl_idname = "import_scene.fbxseq"
    bl_label = "Import FBX Seq"
    bl_options = {"REGISTER", "UNDO"}

    filename_ext = ".fbx"
    filter_glob: StringProperty(default="*.fbx", options={"HIDDEN"})

    files: CollectionProperty(
        name="File Path",
        description="File path used for importing the FBX sequence",
        type=bpy.types.OperatorFileListElement,
    )
    directory: StringProperty()

    relative_shapekey: BoolProperty(
        name="Relative ShapeKey",
        description="Import shapes as relative shapekeys. Uncheck to import absolute shapekeys.",
        default=True,
    )

    def execute(self, context):
        filepaths = [Path(self.directory, n.name) for n in self.files]
        if not filepaths:
            filepaths.append(Path(self.directory, self.filename))

        # Ordenar los archivos por número al final del nombre del archivo
        filepaths.sort(key=lambda x: int(x.stem.split('.')[-1]))

        self.create_shapekeys(filepaths)

        return {"FINISHED"}

    def create_shapekeys(self, filepaths):
        # import first fbx
        bpy.ops.import_scene.fbx(filepath=str(filepaths[0]), axis_forward='-Z', axis_up='Y')
        main_obj = bpy.context.selected_objects[-1]
        main_obj.location = (0, 0, 0)
        main_obj.rotation_euler = (1.5708, 0, 0)  # Rota 90 grados en el eje X (en radianes)

        # Create basis shape key if it doesn't exist
        if not main_obj.data.shape_keys:
            main_obj.shape_key_add(name="Basis")

        seq_len = len(filepaths)

        # Import the rest and create shape keys
        for i, filepath in enumerate(filepaths[1:]):
            bpy.ops.import_scene.fbx(filepath=str(filepath), axis_forward='-Z', axis_up='Y')
            current_obj = bpy.context.selected_objects[-1]
            current_obj.location = (0, 0, 0)
            current_obj.rotation_euler = (1.5708, 0, 0)  # Rota 90 grados en el eje X (en radianes)

            # Join as shapes
            bpy.context.view_layer.objects.active = main_obj
            bpy.ops.object.join_shapes()

            # Remove imported objects
            bpy.data.objects.remove(current_obj, do_unlink=True)

        # Set keyframes or drivers for shape keys
        if seq_len > 1:
            for i, key_block in enumerate(main_obj.data.shape_keys.key_blocks):
                if i > 0:
                    key_block.value = 0.0
                    key_block.keyframe_insert("value", frame=i)
                    key_block.value = 1.0
                    key_block.keyframe_insert("value", frame=i + 1)
                    key_block.value = 0.0
                    key_block.keyframe_insert("value", frame=i + 2)

        # Set start/end time
        bpy.context.scene.frame_start = 0
        bpy.context.scene.frame_end = seq_len - 1


def menu_func_import(self, context):
    self.layout.operator(ImportFbxSeq.bl_idname, text="FBX Seq As Shapekey(.fbx)")


def register():
    bpy.utils.register_class(ImportFbxSeq)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)


def unregister():
    bpy.utils.unregister_class(ImportFbxSeq)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)


if __name__ == "__main__":
    register()
